//
//  ViewController.swift
//  annotation_app_6
//
//  Created by Braun, Annika on 1/22/19.
//  Copyright © 2019 Braun, Annika. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

